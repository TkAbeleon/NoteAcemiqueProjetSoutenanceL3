1. Mr Adulson est ouvrier professionnel très qualifier. Il y a une anceinté de 3 ans. Son salaire mensuel et de 420 000 Ar. Son employeur met fait en contrat sans préavis et son faute lourde. Il n'y pas encore pris son congé annuel. 
	1. Définir les termes suivant: salaire, congé, préavis, et employeur
	2. À quelle groupe professionnel appartient Mr Adulson
	3. Calculer l'indemnité comparatrice de préavis
	4. Quel est le montant de l'indemnité du congé payé
	5. Donner le montant total de toutes les sommes qu'il doit recevoir au titre de préavis et du congé